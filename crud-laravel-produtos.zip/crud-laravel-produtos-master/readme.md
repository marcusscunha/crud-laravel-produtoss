<p align="center"><img src="https://laravel.com/assets/img/components/logo-laravel.svg"></p>
<p align="center"><img src="http://vhcode.com.br/assets/img/logo.png"></p>



## Projeto simples

É um CRUD padrão para começar qualquer projeto em Laravel.


## O que vem nele?

- Já vem com autenticação padrão de usuário já com algumas traduções.

- Um crud pronto de produtos para modelo.

## Contributing

Se quiser contribuir entre em contato que vamos melhorar esse starter

## Get Starter / Começando

Vá no arquivo .env configure seu banco de dados

No terminal entre na pasta da sua aplicação execute o comando:

"php artisan migrate"

Pronto ele estára pronto para uso.

